const express=require('express'),http=require('http'),path=require('path'),crypto=require('crypto');
const {Server}=require('socket.io'),Database=require('better-sqlite3'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken');
const SECRET=process.env.JWT_SECRET||'dev-secret-change-me',PORT=process.env.PORT||3000;
const LOBBY_SIZE=+process.env.LOBBY_SIZE||20,LOBBY_MIN=+process.env.LOBBY_MINUTES||10;
const db=new Database(process.env.DB||'nexora.db');db.pragma('journal_mode=WAL');
db.exec(`create table if not exists users(id integer primary key,username text unique,pass text,name text,gender text,country text,city text,avatar text,score int default 0,active_min int default 0,last_min int default 0,is_admin int default 0,created int);
create table if not exists groups(id integer primary key,name text,code text unique,color text default '#8b5cf6',created int);
create table if not exists members(gid int,uid int,role text,suspended_until int default 0,joined int,primary key(gid,uid));
create table if not exists requests(id integer primary key,gid int,uid int,status text default 'pending',ts int);
create table if not exists messages(id integer primary key,gid int,uid int,text text,ts int);
create table if not exists logs(id integer primary key,uid int,action text,meta text,ts int);`);
const q=(s,...a)=>db.prepare(s).get(...a),all=(s,...a)=>db.prepare(s).all(...a),run=(s,...a)=>db.prepare(s).run(...a);
const log=(uid,a,m='')=>run('insert into logs(uid,action,meta,ts) values(?,?,?,?)',uid,a,String(m),Date.now());
const purge=()=>run('delete from logs where ts<?',Date.now()-90*864e5);purge();setInterval(purge,864e5); // 90-day log retention
const mem=(g,u)=>q('select * from members where gid=? and uid=?',g,u),adm=m=>m&&m.role!=='member';
const pub=u=>u&&{id:u.id,name:u.name,gender:u.gender,country:u.country,city:u.city,score:u.score,groups:q('select count(*) c from members where uid=?',u.id).c,avatar:`/api/avatar/${u.id}`,is_admin:!!u.is_admin};
const ginfo=(g,uid)=>{const n=q('select count(*) c from members where gid=?',g.id).c,m=uid&&mem(g.id,uid);
 return{id:g.id,name:g.name,color:g.color,members:n,tick:n>=10,role:m?m.role:null,code:m?g.code:undefined,pending:!!(uid&&!m&&q("select 1 from requests where gid=? and uid=? and status='pending'",g.id,uid))}};
const app=express(),server=http.createServer(app),io=new Server(server);
app.use(express.json({limit:'1mb'}));app.use(express.static(path.join(__dirname,'public')));
app.get('/join/:c',(r,s)=>s.sendFile(path.join(__dirname,'public/index.html')));
const rl={};setInterval(()=>{for(const k in rl)delete rl[k]},6e4);
const limit=n=>(r,s,next)=>{const k=r.ip+r.path;rl[k]=(rl[k]||0)+1;rl[k]>n?s.status(429).json({error:'Too many requests, slow down'}):next()};
const auth=(r,s,next)=>{try{r.u=q('select * from users where id=?',jwt.verify((r.headers.authorization||'').slice(7),SECRET).id);if(!r.u)throw 0;next()}catch{s.status(401).json({error:'Please log in'})}};
const wrap=f=>(r,s)=>{try{s.json(f(r,s)??{ok:1})}catch(e){s.status(e.code||400).json({error:e.message})}};
const bad=(m,c=400)=>{const e=Error(m);e.code=c;throw e};
const tok=u=>({token:jwt.sign({id:u.id},SECRET,{expiresIn:'30d'}),me:pub(u)});
// ---- auth & profile
app.post('/api/register',limit(10),wrap(r=>{const{username,password,name,gender,country,city}=r.body;
 if(!/^[a-z0-9_]{3,20}$/i.test(username||'')||(password||'').length<6||!(name||'').trim()||!['Male','Female'].includes(gender)||!country||!(city||'').trim())bad('Fill all fields (username 3-20 letters/numbers, password 6+)');
 if(q('select 1 from users where username=?',username.toLowerCase()))bad('Username already taken');
 const first=!q('select 1 from users limit 1');
 const id=run('insert into users(username,pass,name,gender,country,city,is_admin,created) values(?,?,?,?,?,?,?,?)',username.toLowerCase(),bcrypt.hashSync(password,10),name.trim().slice(0,30),gender,country,city.trim().slice(0,40),first?1:0,Date.now()).lastInsertRowid;
 log(id,'register');return tok(q('select * from users where id=?',id))}));
app.post('/api/login',limit(20),wrap(r=>{const u=q('select * from users where username=?',String(r.body.username||'').toLowerCase());
 if(!u||!bcrypt.compareSync(r.body.password||'',u.pass))bad('Wrong username or password',401);log(u.id,'login');return tok(u)}));
app.get('/api/me',auth,wrap(r=>pub(r.u)));
app.get('/api/users/:id',auth,wrap(r=>pub(q('select * from users where id=?',r.params.id))||bad('Not found',404)));
app.put('/api/me',auth,wrap(r=>{const{name,gender,country,city,avatar}=r.body;
 if(!(name||'').trim()||!['Male','Female'].includes(gender)||!country||!(city||'').trim())bad('Fill all fields');
 if(avatar&&(!/^data:image\/(png|jpe?g|webp);base64,/.test(avatar)||avatar.length>250000))bad('Invalid or too large picture');
 run('update users set name=?,gender=?,country=?,city=?,avatar=coalesce(?,avatar) where id=?',name.trim().slice(0,30),gender,country,city.trim().slice(0,40),avatar||null,r.u.id);
 log(r.u.id,'profile_update');return pub(q('select * from users where id=?',r.u.id))}));
app.get('/api/avatar/:id',(r,s)=>{const u=q('select name,avatar from users where id=?',r.params.id);if(!u)return s.sendStatus(404);
 const m=(u.avatar||'').match(/^data:(image\/\w+);base64,(.+)$/);
 if(m)return s.type(m[1]).send(Buffer.from(m[2],'base64'));
 s.type('svg').send(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="hsl(${u.name.charCodeAt(0)*37%360},55%,45%)"/><text x="32" y="43" font-size="30" text-anchor="middle" fill="#fff" font-family="sans-serif">${u.name[0].toUpperCase().replace(/[<>&]/g,'?')}</text></svg>`)});
// ---- groups
app.get('/api/groups/mine',auth,wrap(r=>all('select g.* from groups g join members m on m.gid=g.id where m.uid=? order by g.id',r.u.id).map(g=>ginfo(g,r.u.id))));
app.get('/api/groups/search',auth,wrap(r=>all('select * from groups where name like ? limit 20','%'+String(r.query.q||'').replace(/[%_]/g,'')+'%').map(g=>ginfo(g,r.u.id))));
app.post('/api/groups',auth,limit(10),wrap(r=>{const name=String(r.body.name||'').trim().slice(0,40);if(name.length<2)bad('Group name too short');
 const color=/^#[0-9a-f]{6}$/i.test(r.body.color)?r.body.color:'#8b5cf6',now=Date.now();
 const id=run('insert into groups(name,code,color,created) values(?,?,?,?)',name,crypto.randomBytes(5).toString('hex'),color,now).lastInsertRowid;
 run("insert into members values(?,?,'owner',0,?)",id,r.u.id,now);log(r.u.id,'group_create',name);io.in('u:'+r.u.id).socketsJoin('g:'+id);return ginfo(q('select * from groups where id=?',id),r.u.id)}));
const group=r=>q('select * from groups where id=?',r.params.id)||bad('Group not found',404);
const needAdm=(g,u)=>adm(mem(g.id,u.id))||bad('Admins only',403);
app.put('/api/groups/:id',auth,wrap(r=>{const g=group(r);needAdm(g,r.u);const name=String(r.body.name||g.name).trim().slice(0,40),color=/^#[0-9a-f]{6}$/i.test(r.body.color)?r.body.color:g.color;
 run('update groups set name=?,color=? where id=?',name,color,g.id);log(r.u.id,'group_edit',g.id);return ginfo(q('select * from groups where id=?',g.id),r.u.id)}));
const reqJoin=(g,u)=>{if(mem(g.id,u.id))bad('You are already a member');
 if(!q("select 1 from requests where gid=? and uid=? and status='pending'",g.id,u.id))run('insert into requests(gid,uid,ts) values(?,?,?)',g.id,u.id,Date.now());log(u.id,'join_request',g.id)};
app.post('/api/groups/:id/join',auth,wrap(r=>reqJoin(group(r),r.u)));
app.get('/api/invite/:code',auth,wrap(r=>{const g=q('select * from groups where code=?',r.params.code)||bad('Invalid invite link',404);return ginfo(g,r.u.id)}));
app.post('/api/invite/:code/join',auth,wrap(r=>reqJoin(q('select * from groups where code=?',r.params.code)||bad('Invalid invite link',404),r.u)));
app.get('/api/groups/:id/requests',auth,wrap(r=>{const g=group(r);needAdm(g,r.u);return all("select r.id,u.id uid,u.name,u.country,u.city from requests r join users u on u.id=r.uid where r.gid=? and r.status='pending'",g.id)}));
app.post('/api/requests/:id/:act',auth,wrap(r=>{const rq=q("select * from requests where id=? and status='pending'",r.params.id)||bad('Request not found',404);needAdm({id:rq.gid},r.u);
 if(r.params.act==='approve'){run("insert or ignore into members values(?,?,'member',0,?)",rq.gid,rq.uid,Date.now());io.in('u:'+rq.uid).socketsJoin('g:'+rq.gid);io.to('u:'+rq.uid).emit('groups_changed')}
 run('update requests set status=? where id=?',r.params.act==='approve'?'approved':'rejected',rq.id);log(r.u.id,'request_'+r.params.act,rq.uid)}));
app.get('/api/groups/:id/members',auth,wrap(r=>{const g=group(r);mem(g.id,r.u.id)||bad('Members only',403);
 return all('select u.id,u.name,u.country,u.city,m.role,m.suspended_until from members m join users u on u.id=m.uid where m.gid=? order by m.joined',g.id).map(x=>({...x,suspended:x.suspended_until>Date.now()}))}));
app.post('/api/groups/:id/role',auth,wrap(r=>{const g=group(r),me=mem(g.id,r.u.id);if(!me||me.role!=='owner')bad('Only the owner can appoint admins',403);
 const t=mem(g.id,r.body.uid);if(!t||t.role==='owner')bad('Invalid member');run('update members set role=? where gid=? and uid=?',r.body.role==='admin'?'admin':'member',g.id,t.uid);log(r.u.id,'role_change',t.uid)}));
app.post('/api/groups/:id/suspend',auth,wrap(r=>{const g=group(r),me=mem(g.id,r.u.id);needAdm(g,r.u);const t=mem(g.id,r.body.uid);
 if(!t||t.role==='owner'||(t.role==='admin'&&me.role!=='owner')||t.uid===r.u.id)bad('You cannot suspend this member',403);
 run('update members set suspended_until=? where gid=? and uid=?',r.body.on?Date.now()+864e5:0,g.id,t.uid);log(r.u.id,r.body.on?'suspend':'unsuspend',t.uid)}));
app.post('/api/groups/:id/leave',auth,wrap(r=>{const g=group(r),m=mem(g.id,r.u.id)||bad('Not a member');
 if(m.role==='owner'){const nx=q("select uid from members where gid=? and uid!=? order by (role='admin') desc,joined limit 1",g.id,r.u.id);
  if(!nx){run('delete from groups where id=?',g.id);run('delete from messages where gid=?',g.id)}else run("update members set role='owner' where gid=? and uid=?",g.id,nx.uid)}
 run('delete from members where gid=? and uid=?',g.id,r.u.id);io.in('u:'+r.u.id).socketsLeave('g:'+g.id);log(r.u.id,'group_leave',g.id)}));
app.get('/api/groups/:id/messages',auth,wrap(r=>{const g=group(r);mem(g.id,r.u.id)||bad('Members only',403);
 return all('select * from (select * from messages where gid=? order by id desc limit 100) order by id',g.id).map(m=>({...m,user:pub(q('select * from users where id=?',m.uid))}))}));
// ---- admin dashboard
app.get('/api/admin/overview',auth,wrap(r=>{r.u.is_admin||bad('Forbidden',403);const c=t=>q(`select count(*) c from ${t}`).c;
 return{stats:{users:c('users'),groups:c('groups'),messages:c('messages')},top:all('select name,score from users order by score desc limit 5'),
  logs:all('select l.action,l.meta,l.ts,u.name from logs l left join users u on u.id=l.uid order by l.id desc limit 80')}}));
// ---- realtime
const last={};const spam=(u,t)=>{const l=last[u],n=Date.now();if(l&&n-l.t<1500)return 'Slow down a little';if(l&&l.x===t&&n-l.t<3e4)return 'Duplicate message';last[u]={t:n,x:t}};
const award=uid=>{const m=Math.floor(Date.now()/6e4),u=q('select score,active_min,last_min from users where id=?',uid);if(u.last_min===m)return;
 const a=u.active_min+1,add=a%5===0?20:0; // each qualifying minute counts once; 5 minutes = 20 points
 run('update users set active_min=?,last_min=?,score=score+? where id=?',a,m,add,uid);if(add)io.to('u:'+uid).emit('score',u.score+add)};
let queue=[];const sessions={},qcast=()=>queue.forEach(s=>s.emit('lobby_queue',{n:queue.length,size:LOBBY_SIZE}));
io.use((s,next)=>{try{s.uid=jwt.verify(s.handshake.auth.token,SECRET).id;next()}catch{next(Error('auth'))}});
io.on('connection',s=>{s.join('u:'+s.uid);all('select gid from members where uid=?',s.uid).forEach(m=>s.join('g:'+m.gid));
 s.on('msg',({gid,text},ack)=>{try{text=String(text||'').trim().slice(0,1000);const m=mem(gid,s.uid);if(!m||!text)bad('Not allowed');
  if(m.suspended_until>Date.now())bad('You are suspended until '+new Date(m.suspended_until).toLocaleString());const e=spam(s.uid,text);if(e)bad(e);
  const ts=Date.now(),id=run('insert into messages(gid,uid,text,ts) values(?,?,?,?)',gid,s.uid,text,ts).lastInsertRowid;
  io.to('g:'+gid).emit('msg',{id,gid,text,ts,user:pub(q('select * from users where id=?',s.uid))});log(s.uid,'message',gid);award(s.uid);ack&&ack({})}catch(e){ack&&ack({error:e.message})}});
 s.on('lobby_join',()=>{if(s.sid||queue.includes(s))return;queue.push(s);log(s.uid,'lobby_join');
  if(queue.length>=LOBBY_SIZE){const ps=queue.splice(0,LOBBY_SIZE),id=crypto.randomBytes(4).toString('hex'),end=Date.now()+LOBBY_MIN*6e4;
   const ses=sessions[id]={end,users:ps.map(p=>pub(q('select * from users where id=?',p.uid)))};
   ps.forEach(p=>{p.sid=id;p.join('l:'+id);p.emit('lobby_start',{id,end,users:ses.users})});
   setTimeout(()=>{io.to('l:'+id).emit('lobby_end');io.in('l:'+id).socketsLeave('l:'+id);ps.forEach(p=>p.sid=null);delete sessions[id]},LOBBY_MIN*6e4)}
  qcast()});
 const out=()=>{queue=queue.filter(x=>x!==s);if(s.sid){s.leave('l:'+s.sid);s.sid=null}qcast()};
 s.on('lobby_leave',out);s.on('disconnect',out);
 s.on('lobby_msg',({text},ack)=>{try{text=String(text||'').trim().slice(0,500);if(!s.sid||!text)bad('Not in a session');const e=spam(s.uid,text);if(e)bad(e);
  io.to('l:'+s.sid).emit('lobby_msg',{id:Date.now()+Math.random(),text,ts:Date.now(),user:pub(q('select * from users where id=?',s.uid))});award(s.uid);ack&&ack({})}catch(e){ack&&ack({error:e.message})}});
});
server.listen(PORT,()=>console.log('NEXORA running on http://localhost:'+PORT));
