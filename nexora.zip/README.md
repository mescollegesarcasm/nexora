# NEXORA
Requires Node 18+. Run: `npm install && npm start` → http://localhost:3000
The first registered user becomes the platform admin (dashboard). 
Env: JWT_SECRET (set this in production!), PORT, LOBBY_SIZE (default 20; use 2 to test), LOBBY_MINUTES (default 10), DB.
Stack: Express + Socket.IO + SQLite (better-sqlite3), vanilla JS frontend.
